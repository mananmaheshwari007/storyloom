# Agent Rules for Storyloom

- **Backend-Driven Text Changes**: Whenever the user requests text or copy changes, always make the change in the relevant place in the backend/dashboard (e.g. database seeds, CMS models, settings tables, or backend controller defaults) in addition to frontend templates, so changes persist and do not revert when content is updated via the backend.
